package com;


class ConfigPropertiesException extends RuntimeException {

    ConfigPropertiesException(String message, Throwable cause) {
        super(message, cause);
    }
}
